# Expense_Tracker
Using Tkinter as GUI and sqlite3 as a lightweight option
Simplified/lightweight version of working with database and GUI.

# Setup 

- `python3 -m venv venv`
- `source venv/bin/activate`
- `python app.py`
