import db
from tkinter import *
from helpers import *
from tkinter.ttk import *


LARGE_FONT = ("Verdana", 64)


class ExpenseTracker:
    def __init__(self, master):
        self.frame = Frame(master)
        self.frame.pack()
        self.main_window()

    ### display function calls for database update deletion and listing added or deleted#
    def added(self, boxaile):
        myLabel = Label(boxaile, text="The value has been inserted")
        myLabel.grid(row=4, column=0)

    def delete(self, boxaile):
        myLabel = Label(boxaile, text="The value was deleted")
        myLabel.grid(row=4, column=0)

    def display_all(self, database):
        select_all = database
        return select_all

    def insert(self, database, val1, val2, val3):
        goods = val1.get()
        price = val2.get()
        date = val3.get()
        insertion = database(goods, price, date)
        return insertion

    def find_expense(self, database, val1, val2):
        goods = val1.get()
        price = val2.get()
        find = database(goods, price)
        return find

    def delete_expense(self, database, val1, val2):
        goods = val1.get()
        price = val2.get()
        delete = database(goods, price)
        return delete

    ### MAIN WINDOW###
    def main_window(self):

        button6 = Button(self.frame, text="DASHBOARD", command=self.dashboard)
        button6.pack()

        button1 = Button(self.frame, text="Groceries expenses",
                         command=self.groceries)
        button1.pack()

        button2 = Button(self.frame, text="Household expenses",
                         command=self.household)
        button2.pack()

        button3 = Button(self.frame, text="Entertainment expenses",
                         command=self.entertainment)
        button3.pack()

        button4 = Button(self.frame, text="Other expenses", command=self.other)
        button4.pack()

        button5 = Button(self.frame, text="EXIT", command=exit)
        button5.pack()

    ### INSERT VALUES###

    def dashboard(self):

        top = Toplevel(self.frame)
        top.geometry('1000x500')
        top.title('DASHBOARD')

        text = Text(top, width=1000, height=500)
        text.grid(row=1, column=1, columnspan=2)

        good_width = 20
        price_width = 20
        date_width = 20

        line_width = good_width + price_width + date_width + 10

        all = db.select_all()
        disp = ''
        total_price = 0
        for (name, entries) in all:
            disp += '\n' + '-'*(line_width)
            disp += '\n' + f'##### {name} #####'.center(line_width) + '\n'
            disp += '-'*(line_width) + '\n'
            disp += 'good'.center(good_width)
            disp += '   |  '
            disp += 'price'.center(price_width)
            disp += '|  '
            disp += 'date'.center(date_width)
            disp += '\n'
            disp += '-'*(line_width) + '\n'
            category_price = 0
            for entry in entries:
                total_price += entry[2] if entry[2] else 0
                category_price += entry[2] if entry[2] else 0
                disp += f'| {concat_string(str(entry[1]), good_width)} | {concat_string(str(entry[2]), price_width)} | {concat_string(str(entry[3]), date_width)} |\n'
            disp += '-'*(line_width)
            disp += f'\nTotal Price for {name}: {category_price}\n'
        disp += f'\nTotal Price: {total_price}'
        text.delete(1.0, END)
        text.insert(END, self.display_all(disp))

    def groceries(self):

        top = Toplevel(self.frame)
        top.title('Groceries expenses')
        l1 = Label(top, text="Name of good").grid(
            row=1, column=0, sticky=W, pady=2)
        l2 = Label(top, text="Price").grid(row=2, column=0, sticky=W, pady=2)
        l3 = Label(top, text="Date of purchase").grid(
            row=3, column=0, sticky=W, pady=2)

        e1 = Entry(top)
        e1.grid(row=1, column=1, sticky=W, pady=2)
        e2 = Entry(top)
        e2.grid(row=2, column=1, sticky=W, pady=2)
        e3 = Entry(top)
        e3.grid(row=3, column=1, sticky=W, pady=2)

        text = Text(top, width=40, height=10)
        text.grid(row=5, column=1, columnspan=2)

        # BUTTONS###

        B1 = Button(top, text="Insert Values", command=lambda: (
            self.insert(db.insert_groceries, e1, e2, e3), self.added(top)))
        B1.grid(row=1, column=2)

        B2 = Button(top, text="Show All expenses", command=lambda: (text.delete(
            1.0, END), text.insert(END, self.display_all(db.select_all_groceries()))))
        B2.grid(row=2, column=2)

        B3 = Button(top, text="Find value", command=lambda: (text.delete(
            1.0, END), text.insert(END, self.find_expense(db.select_grocery, e1, e2))))
        B3.grid(row=2, column=3)

        B3 = Button(top, text="Delete expense", command=lambda: (
            self.delete_expense(db.delete_grocery, e1, e2), self.delete(top)))
        B3.grid(row=4, column=2)

        B5 = Button(top, text="Exit", command=exit)
        B5.grid(row=4, column=3)

    def household(self):
        top = Toplevel(self.frame)
        top.title('Household expenses')
        l1 = Label(top, text="Name of good").grid(
            row=1, column=0, sticky=W, pady=2)
        l2 = Label(top, text="Price").grid(row=2, column=0, sticky=W, pady=2)
        l3 = Label(top, text="Date of purchase").grid(
            row=3, column=0, sticky=W, pady=2)

        e1 = Entry(top)
        e1.grid(row=1, column=1, sticky=W, pady=2)
        e2 = Entry(top)
        e2.grid(row=2, column=1, sticky=W, pady=2)
        e3 = Entry(top)
        e3.grid(row=3, column=1, sticky=W, pady=2)

        text = Text(top, width=40, height=10)
        text.grid(row=5, column=1, columnspan=2)

        # BUTTONS###

        B1 = Button(top, text="Insert Values",
                    command=lambda: (self.insert(db.insert_household, e1, e2, e3), self.added(top)))
        B1.grid(row=1, column=2)

        B2 = Button(top, text="Show All expenses", command=lambda: (text.delete(
            1.0, END), text.insert(END, self.display_all(db.select_all_household()))))
        B2.grid(row=2, column=2)

        B3 = Button(top, text="Find value", command=lambda: (
            text.delete(1.0, END), text.insert(END, self.find_expense(db.select_household, e1, e2))))
        B3.grid(row=2, column=3)

        B3 = Button(top, text="Delete expense",
                    command=lambda: (self.delete_expense(db.delete_household, e1, e2), self.delete(top)))
        B3.grid(row=4, column=2)

        B5 = Button(top, text="Exit", command=exit)
        B5.grid(row=4, column=3)

    def entertainment(self):
        top = Toplevel(self.frame)
        top.title('Entertainment expenses')
        l1 = Label(top, text="Name of good").grid(
            row=1, column=0, sticky=W, pady=2)
        l2 = Label(top, text="Price").grid(row=2, column=0, sticky=W, pady=2)
        l3 = Label(top, text="Date of purchase").grid(
            row=3, column=0, sticky=W, pady=2)

        e1 = Entry(top)
        e1.grid(row=1, column=1, sticky=W, pady=2)
        e2 = Entry(top)
        e2.grid(row=2, column=1, sticky=W, pady=2)
        e3 = Entry(top)
        e3.grid(row=3, column=1, sticky=W, pady=2)

        text = Text(top, width=40, height=10)
        text.grid(row=5, column=1, columnspan=2)

        # BUTTONS###

        B1 = Button(top, text="Insert Values",
                    command=lambda: (self.insert(db.insert_entertrainment, e1, e2, e3), self.added(top)))
        B1.grid(row=1, column=2)

        B2 = Button(top, text="Show All expenses", command=lambda: (
            text.delete(1.0, END), text.insert(END, self.display_all(db.select_all_entertrainment()))))
        B2.grid(row=2, column=2)

        B3 = Button(top, text="Find value", command=lambda: (
            text.delete(1.0, END), text.insert(END, self.find_expense(db.select_entertainment, e1, e2))))
        B3.grid(row=2, column=3)

        B3 = Button(top, text="Delete expense",
                    command=lambda: (self.delete_expense(db.delete_entertainment, e1, e2), self.delete(top)))
        B3.grid(row=4, column=2)

        B5 = Button(top, text="Exit", command=exit)
        B5.grid(row=4, column=3)

    def other(self):
        top = Toplevel(self.frame)
        top.title('Entertainment expenses')
        l1 = Label(top, text="Name of good").grid(
            row=1, column=0, sticky=W, pady=2)
        l2 = Label(top, text="Price").grid(row=2, column=0, sticky=W, pady=2)
        l3 = Label(top, text="Date of purchase").grid(
            row=3, column=0, sticky=W, pady=2)

        e1 = Entry(top)
        e1.grid(row=1, column=1, sticky=W, pady=2)
        e2 = Entry(top)
        e2.grid(row=2, column=1, sticky=W, pady=2)
        e3 = Entry(top)
        e3.grid(row=3, column=1, sticky=W, pady=2)

        text = Text(top, width=40, height=10)
        text.grid(row=5, column=1, columnspan=2)

        # BUTTONS###

        B1 = Button(top, text="Insert Values",
                    command=lambda: (self.insert(db.insert_other, e1, e2, e3), self.added(top)))
        B1.grid(row=1, column=2)

        B2 = Button(top, text="Show All expenses", command=lambda: (
            text.delete(1.0, END), text.insert(END, self.display_all(db.select_all_other()))))
        B2.grid(row=2, column=2)

        B3 = Button(top, text="Find value", command=lambda: (
            text.delete(1.0, END), text.insert(END, self.find_expense(db.select_other, e1, e2))))
        B3.grid(row=2, column=3)

        B3 = Button(top, text="Delete expense",
                    command=lambda: (self.delete_expense(db.delete_other, e1, e2), self.delete(top)))
        B3.grid(row=4, column=2)

        B5 = Button(top, text="Exit", command=exit)
        B5.grid(row=4, column=3)


def main():
    # db.create_tables(connection)
    root = Tk()
    root.geometry('1000x500')
    root.title("Expense Tracker")
    tracker = ExpenseTracker(root)

    root.mainloop()


main()
