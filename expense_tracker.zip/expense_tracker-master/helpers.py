def concat_string(a: str, desired_len: int):
    if (len(a) > desired_len):
        a = a[0: desired_len]
        return a
    if(len(a) < desired_len):
        a = a.center(desired_len)
    return a
